data:extend({
	{
	    type = "module-category",
	    name = "god-modules"
	},
	{
	    type = "module-category",
	    name = "god-modules-quality"
	},
	{
	    type = "module-category",
	    name = "god-modules-no-prod"
	},
	{
	    type = "module-category",
	    name = "god-modules-no-prod-quality"
	}
})