data:extend({
    {
        type = "int-setting",
        name = "god-speed-module-speed-bonus",
        setting_type = "startup",
        minimum_value = 1,
        default_value = 50,
        maximum_value = 500,
        order = "a1"
    },
    {
        type = "int-setting",
        name = "god-efficiency-module-efficiency-bonus",
        setting_type = "startup",
        minimum_value = 1,
        default_value = 50,
        maximum_value = 500,
        order = "a2"
    },
    {
        type = "int-setting",
        name = "god-productivity-module-productivity-bonus",
        setting_type = "startup",
        minimum_value = 1,
        default_value = 50,
        maximum_value = 500,
        order = "a3"
    },

    {
        type = "int-setting",
        name = "god-quality-module-quality-bonus",
        setting_type = "startup",
        minimum_value = 1,
        default_value = 50,
        maximum_value = 500,
        order = "a4"
    },

    
    {
        type = "int-setting",
        name = "god-module-speed-bonus",
        setting_type = "startup",
        minimum_value = 1,
        default_value = 50,
        maximum_value = 500,
        order = "b1"
    },
    {
        type = "int-setting",
        name = "god-module-efficiency-bonus",
        setting_type = "startup",
        minimum_value = 1,
        default_value = 50,
        maximum_value = 500,
        order = "b2"
    },
    {
        type = "int-setting",
        name = "god-module-productivity-bonus",
        setting_type = "startup",
        minimum_value = 1,
        default_value = 50,
        maximum_value = 500,
        order = "b3"
    },
    {
        type = "int-setting",
        name = "god-module-quality-bonus",
        setting_type = "startup",
        minimum_value = 1,
        default_value = 50,
        maximum_value = 500,
        order = "b4"
    },
    {
        type = "bool-setting",
        name = "god-module-use-quality",
        setting_type = "startup",
        default_value = false,
        order = "d1"
    },
    {
        type = "bool-setting",
        name = "god-module-easier-craft",
        setting_type = "startup",
        default_value = false,
        order = "d2"
    },
    {
        type = "bool-setting",
        name = "god-module-recipe-require-quality",
        setting_type = "startup",
        default_value = false,
        order = "d2"
    }
})